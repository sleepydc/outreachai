import "./globals.css";

export const metadata = {
  title: "OutreachAI — Affiliate Outreach Platform",
  description: "Find creators, send outreach, track deals — powered by Claude Cowork",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
