# OutreachAI

Affiliate outreach platform powered by Claude Cowork. Find creators on TikTok Shop, Instagram, Facebook, and Modash — then send personalized outreach through their native platform UIs.

## Quick Start (Deploy in 5 minutes)

### Option A: Deploy to Vercel (Recommended)

**Step 1: Push to GitHub**
```bash
# Create a new repo on GitHub called "outreachai"
# Then push this project:
git init
git add .
git commit -m "OutreachAI v1.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/outreachai.git
git push -u origin main
```

**Step 2: Deploy on Vercel**
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click "Add New Project"
3. Import your `outreachai` repository
4. Framework: Next.js (auto-detected)
5. Click "Deploy"
6. Wait ~60 seconds. Your app is live at `outreachai.vercel.app`

**Step 3: Connect GoDaddy Domain**

In GoDaddy DNS settings, add these records:

| Type  | Host | Value               | TTL |
|-------|------|---------------------|-----|
| CNAME | www  | cname.vercel-dns.com | 600 |
| A     | @    | 76.76.21.21          | 600 |

Then in Vercel Dashboard → your project → Settings → Domains:
- Add your domain (e.g., `outreachai.com`)
- Vercel auto-provisions SSL (takes ~10 minutes)

### Option B: Run Locally

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## What You'll See

The app is a fully interactive mockup/prototype:

- **Login** — Use any email with @ and password 6+ chars (e.g., `test@test.com` / `123456`)
- **Sessions** — Mark platforms as "logged in" (simulated)
- **Programs** — Create outreach campaigns with platform-specific filters
- **Discover** — Scan for creators (uses mock data), search, sort, skip, view detail panel
- **Compose** — AI-generated personalized messages (simulated), editable, with send confirmation
- **Tracker** — 4-way status tracking, deal pipeline, notes, nudge system

## Current State

This is **Phase 1: Interactive Mockup**. Everything runs client-side with mock data. No real backend, database, or AI calls yet.

### What's Built
- ✅ Complete UI with all pages and flows
- ✅ Login / Register / Forgot Password
- ✅ Browser Sessions management
- ✅ Program creation with full filter sets (TikTok, IG, FB, Modash)
- ✅ Discover with scan simulation, sort, search, skip, detail panel
- ✅ Cross-program duplicate warnings
- ✅ Compose with 3 modes (AI Personalized, AI Standard, Custom)
- ✅ Editable message previews with remove-from-batch
- ✅ Send confirmation modal
- ✅ TikTok invite mode awareness
- ✅ Modash → actual platform routing
- ✅ Outreach Tracker with 4-way status (Pending/Interested/Declined/No Reply)
- ✅ Deal pipeline (Interested → Negotiating → Agreed → Active)
- ✅ Notes per prospect (debounced)
- ✅ Nudge system for pending + no-reply prospects
- ✅ Program delete with outreach cleanup
- ✅ Logout with full state reset

### What's Next (Production Build)
- 🔲 PostgreSQL database (Prisma schema included in `/prisma/schema.prisma`)
- 🔲 NextAuth.js authentication
- 🔲 API routes for CRUD operations
- 🔲 Claude API integration for real AI message generation
- 🔲 Claude Cowork automation scripts
- 🔲 DM sync with watermark system
- 🔲 Email notifications via Resend
- 🔲 Rate limiting and input validation

## Tech Stack

| Layer       | Technology              |
|-------------|------------------------|
| Frontend    | Next.js 14 + React 18  |
| Styling     | Inline CSS (DM Sans + Instrument Serif) |
| Database    | PostgreSQL via Supabase (planned) |
| ORM         | Prisma (schema ready)  |
| Auth        | NextAuth.js (planned)  |
| AI          | Claude API (planned)   |
| Automation  | Claude Cowork in Chrome (planned) |
| Hosting     | Vercel + GoDaddy       |
| Email       | Resend (planned)       |

## Project Structure

```
outreachai/
├── src/
│   └── app/
│       ├── layout.jsx      # Root layout with metadata
│       ├── globals.css      # Global styles, CSS variables
│       └── page.jsx         # Main dashboard (all UI)
├── prisma/
│   └── schema.prisma        # Complete database schema
├── docs/                     # Technical architecture docs
├── public/                   # Static assets
├── package.json
├── next.config.js
├── tsconfig.json
├── .env.example
├── .gitignore
└── README.md
```

## Technical Documentation

All architecture decisions, bug reports, and solutions are in the `/docs/` folder:

| Document | Contents |
|----------|----------|
| `Tech-Doc-v2.docx` | Full Cowork architecture, DB schema, API endpoints |
| `Review-v2.1.docx` | 24 issues: engineering + UX + GoDaddy integration |
| `Bug-Scan.docx` | 41 potential bugs with fixes |
| `MultiProgram-v2.2.docx` | Cross-program dedup, response attribution |
| `DM-Sync-v2.3.docx` | Watermark reconnection system |
| `HardProblems-v2.4.docx` | 9 architectural challenges + solutions |
| `DebugRound-v2.5.docx` | Code-level bugs found by tracing |

## License

Proprietary. All rights reserved.
